import { Todo } from '../class/todo';

export interface AppState {
  readonly todos: Todo[];
}
